using System;
using System.Windows.Forms;
using System.IO;
using System.Text.Json;

namespace LMK
{
    public partial class SettingsForm : Form
    {
        public int ListenPort { get; private set; }
        private TextBox portTextBox;
        public int HeartbeatInterval { get; private set; } = 3;
        private TextBox heartbeatTextBox;
        private Button saveButton;

        public static (int port, int heartbeat) LoadSettings()
        {
            try
            {
                if (File.Exists("settings.json"))
                {
                    var json = File.ReadAllText("settings.json");
                    var obj = JsonSerializer.Deserialize<SettingsData>(json);
                    return (obj.Port, obj.Heartbeat);
                }
            }
            catch { }
            return (5200, 3); // 默认值
        }
        public static void SaveSettings(int port, int heartbeat)
        {
            var obj = new SettingsData { Port = port, Heartbeat = heartbeat };
            var json = JsonSerializer.Serialize(obj);
            File.WriteAllText("settings.json", json);
        }
        private class SettingsData { public int Port { get; set; } public int Heartbeat { get; set; } }

        public SettingsForm(int currentPort, int currentHeartbeat)
        {
            this.Text = "设置";
            this.Width = 300;
            this.Height = 200;
            this.MinimumSize = new System.Drawing.Size(300, 200);

            Label portLabel = new Label() { Text = "监听端口:", Left = 20, Top = 20, Width = 70 };
            portTextBox = new TextBox() { Left = 100, Top = 18, Width = 120, Text = currentPort.ToString() };

            Label heartbeatLabel = new Label() { Text = "心跳检测频率(秒):", Left = 20, Top = 60, Width = 100 };
            heartbeatTextBox = new TextBox() { Left = 130, Top = 58, Width = 90, Text = currentHeartbeat.ToString() };

            saveButton = new Button() { Text = "保存", Left = 100, Top = 110, Width = 80 };
            saveButton.Click += SaveButton_Click;

            this.Controls.Add(portLabel);
            this.Controls.Add(portTextBox);
            this.Controls.Add(heartbeatLabel);
            this.Controls.Add(heartbeatTextBox);
            this.Controls.Add(saveButton);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            LMK.WindowAffinityHelper.SetExcludeFromCapture(this);
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            if (int.TryParse(portTextBox.Text, out int port) && port > 0 && port < 65536
                && int.TryParse(heartbeatTextBox.Text, out int heartbeat) && heartbeat > 0 && heartbeat <= 60)
            {
                ListenPort = port;
                HeartbeatInterval = heartbeat;
                SaveSettings(port, heartbeat);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("请输入有效的端口号 (1-65535) 和心跳频率 (1-60秒)", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
} 