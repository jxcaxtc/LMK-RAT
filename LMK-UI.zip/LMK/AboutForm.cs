using System;
using System.Windows.Forms;
using System.Diagnostics;

namespace LMK
{
    public partial class AboutForm : Form
    {
        public AboutForm()
        {
            this.Text = "关于";
            this.Width = 420;
            this.Height = 350;
            this.MinimumSize = new System.Drawing.Size(420, 350);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterParent;

            var table = new TableLayoutPanel();
            table.Dock = DockStyle.Fill;
            table.ColumnCount = 1;
            table.RowCount = 8;
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 40)); // 标题
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30)); // 作者
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30)); // GitHub
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30)); // 其他链接
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30)); // 赞助商
            table.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); // 占位
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 30)); // 协议
            table.RowStyles.Add(new RowStyle(SizeType.Absolute, 40)); // 关闭按钮

            var title = new Label() { Text = "LM1 RAT", Dock = DockStyle.Fill, TextAlign = System.Drawing.ContentAlignment.MiddleCenter, Font = new System.Drawing.Font("Segoe UI", 20, System.Drawing.FontStyle.Regular) };
            var author = new Label() { Text = "作者：永遠に愛してる[$ǿĀD ]", Dock = DockStyle.Fill, TextAlign = System.Drawing.ContentAlignment.MiddleCenter, Font = new System.Drawing.Font("微软雅黑", 11) };
            var github = new LinkLabel() { Text = "GitHub: 无", Dock = DockStyle.Fill, TextAlign = System.Drawing.ContentAlignment.MiddleCenter, Font = new System.Drawing.Font("微软雅黑", 10) };
            github.Links.Add(8, github.Text.Length - 8, "https://");
            github.LinkClicked += (s, e) => Process.Start(new ProcessStartInfo(e.Link.LinkData.ToString()) { UseShellExecute = true });
            var otherLink = new LinkLabel() { Text = "文档: 无", Dock = DockStyle.Fill, TextAlign = System.Drawing.ContentAlignment.MiddleCenter, Font = new System.Drawing.Font("微软雅黑", 10) };
            otherLink.Links.Add(3, otherLink.Text.Length - 3, "https://");
            otherLink.LinkClicked += (s, e) => Process.Start(new ProcessStartInfo(e.Link.LinkData.ToString()) { UseShellExecute = true });
            var sponsor = new Label() { Text = "qq：3778352083", Dock = DockStyle.Fill, TextAlign = System.Drawing.ContentAlignment.MiddleCenter, Font = new System.Drawing.Font("微软雅黑", 10, System.Drawing.FontStyle.Italic) };
            var license = new Label() { Text = "开源协议：未开源", Dock = DockStyle.Fill, TextAlign = System.Drawing.ContentAlignment.MiddleCenter, Font = new System.Drawing.Font("微软雅黑", 9) };
            var closeBtn = new Button() { Text = "关闭~", Dock = DockStyle.Fill, Height = 30 };
            closeBtn.Click += (s, e) => this.Close();

            // 图标 PictureBox（你可以自行设置图片路径）
            var iconBox = new PictureBox() { Dock = DockStyle.Fill, SizeMode = PictureBoxSizeMode.CenterImage };
            // 示例：iconBox.Image = Image.FromFile("你的图片路径");

            table.Controls.Add(title, 0, 0);
            table.Controls.Add(author, 0, 1);
            table.Controls.Add(github, 0, 2);
            table.Controls.Add(otherLink, 0, 3);
            table.Controls.Add(sponsor, 0, 4);
            table.Controls.Add(iconBox, 0, 5); // 用 PictureBox 占位
            table.Controls.Add(license, 0, 6);
            table.Controls.Add(closeBtn, 0, 7);

            this.Controls.Add(table);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            LMK.WindowAffinityHelper.SetExcludeFromCapture(this);
        }
    }
} 