using System;
using System.Windows.Forms;
using System.Drawing;
using System.Net.Sockets;
using System.Threading;
using System.IO;

namespace LMK
{
    public class CameraMonitorForm : Form
    {
        private PictureBox pictureBox;
        private ContextMenuStrip contextMenu;
        private ToolStripMenuItem qualityMenu;
        private ToolStripMenuItem hdMenuItem;
        private ToolStripMenuItem sdMenuItem;
        private ToolStripMenuItem ldMenuItem;
        private TcpClient cameraClient; // 图片流
        private TcpClient commandClient; // 命令通道
        private Thread recvThread;
        private bool running = false;
        private string targetIp;
        private int targetPort = 5301; // 摄像头流端口
        private int commandPort = 5302; // 摄像头命令端口

        public CameraMonitorForm(string ip = null)
        {
            this.Text = "远程摄像头监控";
            this.Width = 800;
            this.Height = 600;
            pictureBox = new PictureBox();
            pictureBox.Dock = DockStyle.Fill;
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(pictureBox);
            this.MinimumSize = new Size(400, 250);

            // 右键菜单
            contextMenu = new ContextMenuStrip();
            qualityMenu = new ToolStripMenuItem("清晰度");
            hdMenuItem = new ToolStripMenuItem("高清") { CheckOnClick = true };
            sdMenuItem = new ToolStripMenuItem("标清") { CheckOnClick = true };
            ldMenuItem = new ToolStripMenuItem("流畅") { CheckOnClick = true };
            hdMenuItem.Click += (s, e) => SetQuality("HD");
            sdMenuItem.Click += (s, e) => SetQuality("SD");
            ldMenuItem.Click += (s, e) => SetQuality("LD");
            qualityMenu.DropDownItems.AddRange(new ToolStripItem[] { hdMenuItem, sdMenuItem, ldMenuItem });
            contextMenu.Items.Add(qualityMenu);
            pictureBox.ContextMenuStrip = contextMenu;

            // 默认选中高清
            hdMenuItem.Checked = true;

            this.FormClosing += CameraMonitorForm_FormClosing;
            this.Load += CameraMonitorForm_Load;
            if (!string.IsNullOrEmpty(ip))
            {
                targetIp = ip;
            }
        }

        private void CameraMonitorForm_Load(object sender, EventArgs e)
        {
            StartCameraMonitor();
        }

        private void StartCameraMonitor()
        {
            running = true;
            if (string.IsNullOrEmpty(targetIp)) return;
            try
            {
                cameraClient = new TcpClient();
                cameraClient.Connect(targetIp, targetPort);
                recvThread = new Thread(RecvLoop) { IsBackground = true };
                recvThread.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"连接摄像头流失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RecvLoop()
        {
            try
            {
                var stream = cameraClient.GetStream();
                var reader = new BinaryReader(stream);
                while (running)
                {
                    int imgLen = reader.ReadInt32();
                    byte[] imgData = reader.ReadBytes(imgLen);
                    using (var ms = new MemoryStream(imgData))
                    {
                        var img = Image.FromStream(ms);
                        ShowImage(img);
                    }
                }
            }
            catch { }
        }
        private void ShowImage(Image img)
        {
            if (pictureBox.InvokeRequired)
            {
                pictureBox.Invoke(new Action<Image>(ShowImage), img);
            }
            else
            {
                if (pictureBox.Image != null)
                    pictureBox.Image.Dispose();
                pictureBox.Image = (Image)img.Clone();
            }
        }

        private void SetQuality(string quality)
        {
            hdMenuItem.Checked = quality == "HD";
            sdMenuItem.Checked = quality == "SD";
            ldMenuItem.Checked = quality == "LD";
            int val = 90;
            if (quality == "SD") val = 60;
            if (quality == "LD") val = 30;
            try
            {
                if (commandClient == null || !commandClient.Connected)
                {
                    commandClient = new TcpClient();
                    commandClient.Connect(targetIp, commandPort);
                }
                var writer = new StreamWriter(commandClient.GetStream()) { AutoFlush = true };
                writer.WriteLine($"SET_CAM_QUALITY:{val}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"发送清晰度命令失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CameraMonitorForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            running = false;
            try { recvThread?.Join(200); } catch { }
            try { cameraClient?.Close(); } catch { }
            try { commandClient?.Close(); } catch { }
        }
    }
} 