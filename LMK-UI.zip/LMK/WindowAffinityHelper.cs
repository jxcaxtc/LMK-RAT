using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace LMK
{
    public static class WindowAffinityHelper
    {
        private const int WDA_NONE = 0x0;
        private const int WDA_MONITOR = 0x1;
        private const int WDA_EXCLUDEFROMCAPTURE = 0x11; // Win10 2004及以上

        [DllImport("user32.dll")]
        private static extern bool SetWindowDisplayAffinity(IntPtr hWnd, uint dwAffinity);

        public static void SetExcludeFromCapture(Form form)
        {
            try
            {
                SetWindowDisplayAffinity(form.Handle, WDA_EXCLUDEFROMCAPTURE);
            }
            catch { }
        }
    }
} 